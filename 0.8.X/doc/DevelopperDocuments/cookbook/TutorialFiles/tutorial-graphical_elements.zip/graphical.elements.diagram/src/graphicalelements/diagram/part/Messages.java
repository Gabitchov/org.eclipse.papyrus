package graphicalelements.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	 * @generated
	 */
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Messages() {
	}

	/**
	 * @generated
	 */
	public static String GraphicalElementsCreationWizardTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsCreationWizard_DiagramModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsCreationWizard_DiagramModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String GraphicalElementsCreationWizard_DomainModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsCreationWizard_DomainModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String GraphicalElementsCreationWizardOpenEditorError;

	/**
	 * @generated
	 */
	public static String GraphicalElementsCreationWizardCreationError;

	/**
	 * @generated
	 */
	public static String GraphicalElementsCreationWizardPageExtensionError;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDocumentProvider_isModifiable;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDocumentProvider_handleElementContentChanged;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDocumentProvider_IncorrectInputError;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDocumentProvider_NoDiagramInResourceError;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDocumentProvider_DiagramLoadingError;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDocumentProvider_UnsynchronizedFileSaveError;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDocumentProvider_SaveDiagramTask;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDocumentProvider_SaveNextResourceTask;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDocumentProvider_SaveAsOperation;

	/**
	 * @generated
	 */
	public static String GraphicalElementsInitDiagramFileAction_InitDiagramFileResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsInitDiagramFileAction_InitDiagramFileResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String GraphicalElementsInitDiagramFileAction_InitDiagramFileWizardTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsInitDiagramFileAction_OpenModelFileDialogTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_CreationPageName;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_CreationPageTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_CreationPageDescription;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_RootSelectionPageName;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_InitDiagramCommand;

	/**
	 * @generated
	 */
	public static String GraphicalElementsNewDiagramFileWizard_IncorrectRootError;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDiagramEditor_SavingDeletedFile;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDiagramEditor_SaveAsErrorTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDiagramEditor_SaveAsErrorMessage;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDiagramEditor_SaveErrorTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsDiagramEditor_SaveErrorMessage;

	/**
	 * @generated
	 */
	public static String GraphicalElementsElementChooserDialog_SelectModelElementTitle;

	/**
	 * @generated
	 */
	public static String ModelElementSelectionPageMessage;

	/**
	 * @generated
	 */
	public static String ValidateActionMessage;

	/**
	 * @generated
	 */
	public static String Default1Group_title;

	/**
	 * @generated
	 */
	public static String Default1Group_desc;

	/**
	 * @generated
	 */
	public static String CreateInteraction1CreationTool_title;

	/**
	 * @generated
	 */
	public static String CreateInteraction1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String CreateLifeline2CreationTool_title;

	/**
	 * @generated
	 */
	public static String CreateBehavior3CreationTool_title;

	/**
	 * @generated
	 */
	public static String InteractionInteractionCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String LifelineLifelineCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String CommandName_OpenDiagram;

	/**
	 * @generated
	 */
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnexpectedValueTypeMessage;

	/**
	 * @generated
	 */
	public static String AbstractParser_WrongStringConversionMessage;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnknownLiteralMessage;

	/**
	 * @generated
	 */
	public static String MessageFormatParser_InvalidInputError;

	/**
	 * @generated
	 */
	public static String GraphicalElementsModelingAssistantProviderTitle;

	/**
	 * @generated
	 */
	public static String GraphicalElementsModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
