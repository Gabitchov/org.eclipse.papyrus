package graphicalelements.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {

}
