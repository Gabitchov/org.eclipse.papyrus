package graphicalelements.diagram.edit.helpers;

/**
 * @generated
 */
public class RootEditHelper extends GraphicalElementsBaseEditHelper {
}
