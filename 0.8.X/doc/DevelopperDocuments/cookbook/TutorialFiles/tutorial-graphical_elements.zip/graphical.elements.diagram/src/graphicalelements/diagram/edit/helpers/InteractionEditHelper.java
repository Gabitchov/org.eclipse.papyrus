package graphicalelements.diagram.edit.helpers;

/**
 * @generated
 */
public class InteractionEditHelper extends GraphicalElementsBaseEditHelper {
}
