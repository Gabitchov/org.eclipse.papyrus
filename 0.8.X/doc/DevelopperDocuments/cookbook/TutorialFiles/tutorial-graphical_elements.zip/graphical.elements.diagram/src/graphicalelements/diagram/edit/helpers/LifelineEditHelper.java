package graphicalelements.diagram.edit.helpers;

/**
 * @generated
 */
public class LifelineEditHelper extends GraphicalElementsBaseEditHelper {
}
