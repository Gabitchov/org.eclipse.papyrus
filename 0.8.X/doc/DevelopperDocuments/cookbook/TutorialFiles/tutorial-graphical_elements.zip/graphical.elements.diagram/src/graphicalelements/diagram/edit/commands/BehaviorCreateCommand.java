package graphicalelements.diagram.edit.commands;

import graphicalelements.GraphicalelementsPackage;
import graphicalelements.Lifeline;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.emf.type.core.commands.CreateElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class BehaviorCreateCommand extends CreateElementCommand {

	/**
	 * @generated
	 */
	public BehaviorCreateCommand(CreateElementRequest req) {
		super(req);
	}

	/**
	 * @generated NOT
	 */
	protected EObject getElementToEdit() {
		EObject container = ((CreateElementRequest) getRequest())
				.getContainer();
		if (container instanceof View) {
			container = ((View) container).getElement();
		}

		if (container instanceof Lifeline)
			container = container.eContainer();

		return container;
	}

	/**
	 * @generated
	 */
	protected EClass getEClassToEdit() {
		return GraphicalelementsPackage.eINSTANCE.getInteraction();
	}

}
