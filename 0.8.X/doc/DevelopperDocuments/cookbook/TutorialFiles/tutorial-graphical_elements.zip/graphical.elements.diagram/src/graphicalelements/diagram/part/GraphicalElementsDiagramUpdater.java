package graphicalelements.diagram.part;

import graphicalelements.Behavior;
import graphicalelements.Interaction;
import graphicalelements.Lifeline;
import graphicalelements.Root;
import graphicalelements.diagram.edit.parts.BehaviorEditPart;
import graphicalelements.diagram.edit.parts.InteractionEditPart;
import graphicalelements.diagram.edit.parts.InteractionInteractionCompartmentEditPart;
import graphicalelements.diagram.edit.parts.LifelineEditPart;
import graphicalelements.diagram.edit.parts.LifelineLifelineCompartmentEditPart;
import graphicalelements.diagram.edit.parts.RootEditPart;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class GraphicalElementsDiagramUpdater {

	/**
	 * @generated
	 */
	public static List getSemanticChildren(View view) {
		switch (GraphicalElementsVisualIDRegistry.getVisualID(view)) {
		case InteractionInteractionCompartmentEditPart.VISUAL_ID:
			return getInteractionInteractionCompartment_7001SemanticChildren(view);
		case LifelineLifelineCompartmentEditPart.VISUAL_ID:
			return getLifelineLifelineCompartment_7003SemanticChildren(view);
		case RootEditPart.VISUAL_ID:
			return getRoot_1000SemanticChildren(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getInteractionInteractionCompartment_7001SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		Interaction modelElement = (Interaction) containerView.getElement();
		List result = new LinkedList();
		for (Iterator it = modelElement.getLifelines().iterator(); it.hasNext();) {
			Lifeline childElement = (Lifeline) it.next();
			int visualID = GraphicalElementsVisualIDRegistry.getNodeVisualID(
					view, childElement);
			if (visualID == LifelineEditPart.VISUAL_ID) {
				result.add(new GraphicalElementsNodeDescriptor(childElement,
						visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated NOT
	 */
	public static List getLifelineLifelineCompartment_7003SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		Lifeline modelElement = (Lifeline) containerView.getElement();
		Interaction parentElement = (Interaction) modelElement.eContainer();
		List result = new LinkedList();
		for (Iterator it = parentElement.getBehaviors().iterator(); it
				.hasNext();) {
			Behavior childElement = (Behavior) it.next();
			int visualID = GraphicalElementsVisualIDRegistry.getNodeVisualID(
					view, childElement);
			if (visualID == BehaviorEditPart.VISUAL_ID) {
				// The Behavior must belong to the Lifeline
				Behavior behavior = (Behavior) childElement;
				if (behavior.getBelongsTo() == modelElement)
					result.add(new GraphicalElementsNodeDescriptor(
							childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getRoot_1000SemanticChildren(View view) {
		if (!view.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		Root modelElement = (Root) view.getElement();
		List result = new LinkedList();
		for (Iterator it = modelElement.getInteractions().iterator(); it
				.hasNext();) {
			Interaction childElement = (Interaction) it.next();
			int visualID = GraphicalElementsVisualIDRegistry.getNodeVisualID(
					view, childElement);
			if (visualID == InteractionEditPart.VISUAL_ID) {
				result.add(new GraphicalElementsNodeDescriptor(childElement,
						visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getContainedLinks(View view) {
		switch (GraphicalElementsVisualIDRegistry.getVisualID(view)) {
		case RootEditPart.VISUAL_ID:
			return getRoot_1000ContainedLinks(view);
		case InteractionEditPart.VISUAL_ID:
			return getInteraction_2001ContainedLinks(view);
		case LifelineEditPart.VISUAL_ID:
			return getLifeline_3003ContainedLinks(view);
		case BehaviorEditPart.VISUAL_ID:
			return getBehavior_3004ContainedLinks(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getIncomingLinks(View view) {
		switch (GraphicalElementsVisualIDRegistry.getVisualID(view)) {
		case InteractionEditPart.VISUAL_ID:
			return getInteraction_2001IncomingLinks(view);
		case LifelineEditPart.VISUAL_ID:
			return getLifeline_3003IncomingLinks(view);
		case BehaviorEditPart.VISUAL_ID:
			return getBehavior_3004IncomingLinks(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getOutgoingLinks(View view) {
		switch (GraphicalElementsVisualIDRegistry.getVisualID(view)) {
		case InteractionEditPart.VISUAL_ID:
			return getInteraction_2001OutgoingLinks(view);
		case LifelineEditPart.VISUAL_ID:
			return getLifeline_3003OutgoingLinks(view);
		case BehaviorEditPart.VISUAL_ID:
			return getBehavior_3004OutgoingLinks(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getRoot_1000ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getInteraction_2001ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getLifeline_3003ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getBehavior_3004ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getInteraction_2001IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getLifeline_3003IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getBehavior_3004IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getInteraction_2001OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getLifeline_3003OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getBehavior_3004OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

}
