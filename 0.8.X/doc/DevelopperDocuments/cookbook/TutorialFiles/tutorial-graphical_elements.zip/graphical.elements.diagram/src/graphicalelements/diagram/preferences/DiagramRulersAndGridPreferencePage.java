package graphicalelements.diagram.preferences;

import graphicalelements.diagram.part.GraphicalElementsDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(GraphicalElementsDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
