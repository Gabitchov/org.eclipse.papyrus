package graphicalelements.diagram.edit.helpers;

/**
 * @generated
 */
public class BehaviorEditHelper extends GraphicalElementsBaseEditHelper {
}
