package graphicalelements.diagram.navigator;

import graphicalelements.diagram.part.GraphicalElementsVisualIDRegistry;

import org.eclipse.jface.viewers.ViewerSorter;

/**
 * @generated
 */
public class GraphicalElementsNavigatorSorter extends ViewerSorter {

	/**
	 * @generated
	 */
	private static final int GROUP_CATEGORY = 7005;

	/**
	 * @generated
	 */
	public int category(Object element) {
		if (element instanceof GraphicalElementsNavigatorItem) {
			GraphicalElementsNavigatorItem item = (GraphicalElementsNavigatorItem) element;
			return GraphicalElementsVisualIDRegistry
					.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
