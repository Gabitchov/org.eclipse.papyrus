package graphicalelements.diagram.part;

import org.eclipse.gmf.runtime.diagram.ui.parts.DiagramActionBarContributor;

/**
 * @generated
 */
public class GraphicalElementsDiagramActionBarContributor extends
		DiagramActionBarContributor {

	/**
	 * @generated
	 */
	protected Class getEditorClass() {
		return GraphicalElementsDiagramEditor.class;
	}

	/**
	 * @generated
	 */
	protected String getEditorId() {
		return GraphicalElementsDiagramEditor.ID;
	}
}
