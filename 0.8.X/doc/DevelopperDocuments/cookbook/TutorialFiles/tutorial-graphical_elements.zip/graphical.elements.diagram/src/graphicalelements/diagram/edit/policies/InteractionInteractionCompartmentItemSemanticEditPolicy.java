package graphicalelements.diagram.edit.policies;

import graphicalelements.GraphicalelementsPackage;
import graphicalelements.diagram.edit.commands.LifelineCreateCommand;
import graphicalelements.diagram.providers.GraphicalElementsElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class InteractionInteractionCompartmentItemSemanticEditPolicy extends
		GraphicalElementsBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (GraphicalElementsElementTypes.Lifeline_3003 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(GraphicalelementsPackage.eINSTANCE
						.getInteraction_Lifelines());
			}
			return getGEFWrapper(new LifelineCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
