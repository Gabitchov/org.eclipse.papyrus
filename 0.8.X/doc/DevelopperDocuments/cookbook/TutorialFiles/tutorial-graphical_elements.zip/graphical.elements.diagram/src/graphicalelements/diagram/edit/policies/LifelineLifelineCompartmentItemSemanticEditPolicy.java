package graphicalelements.diagram.edit.policies;

import graphicalelements.GraphicalelementsPackage;
import graphicalelements.diagram.edit.commands.BehaviorCreateCommand;
import graphicalelements.diagram.edit.commands.CreateElementAndInitializeFeatureCommand;
import graphicalelements.diagram.providers.GraphicalElementsElementTypes;

import org.eclipse.emf.ecore.EReference;
import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.commands.CreateElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class LifelineLifelineCompartmentItemSemanticEditPolicy extends
		GraphicalElementsBaseItemSemanticEditPolicy {

	/**
	 * @generated NOT
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (GraphicalElementsElementTypes.Behavior_3004 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(GraphicalelementsPackage.eINSTANCE
						.getInteraction_Behaviors());
			}
			// Added to initialize the property "BelongsTo" of the new Behaviour
			CreateElementCommand behaviorCmd = new BehaviorCreateCommand(req);
			EReference feature = GraphicalelementsPackage.eINSTANCE
					.getBehavior_BelongsTo();
			Object value = req.getContainer();
			return new CreateElementAndInitializeFeatureCommand(behaviorCmd,
					feature, value);
						return getGEFWrapper(new BehaviorCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
