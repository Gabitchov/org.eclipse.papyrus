package graphicalelements.diagram.part;

import graphicalelements.diagram.providers.GraphicalElementsElementTypes;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.gef.Tool;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeCreationTool;

/**
 * @generated
 */
public class GraphicalElementsPaletteFactory {

	/**
	 * @generated
	 */
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createDefault1Group());
	}

	/**
	 * Creates "Default" palette tool group
	 * @generated
	 */
	private PaletteContainer createDefault1Group() {
		PaletteGroup paletteContainer = new PaletteGroup(
				Messages.Default1Group_title);
		paletteContainer.setDescription(Messages.Default1Group_desc);
		paletteContainer.add(createCreateInteraction1CreationTool());
		paletteContainer.add(createCreateLifeline2CreationTool());
		paletteContainer.add(createCreateBehavior3CreationTool());
		return paletteContainer;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreateInteraction1CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(GraphicalElementsElementTypes.Interaction_2001);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.CreateInteraction1CreationTool_title,
				Messages.CreateInteraction1CreationTool_desc, types);
		entry
				.setSmallIcon(GraphicalElementsElementTypes
						.getImageDescriptor(GraphicalElementsElementTypes.Interaction_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreateLifeline2CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(GraphicalElementsElementTypes.Lifeline_3003);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.CreateLifeline2CreationTool_title, null, types);
		entry
				.setSmallIcon(GraphicalElementsElementTypes
						.getImageDescriptor(GraphicalElementsElementTypes.Lifeline_3003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreateBehavior3CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(GraphicalElementsElementTypes.Behavior_3004);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.CreateBehavior3CreationTool_title, null, types);
		entry
				.setSmallIcon(GraphicalElementsElementTypes
						.getImageDescriptor(GraphicalElementsElementTypes.Behavior_3004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private static class NodeToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List elementTypes;

		/**
		 * @generated
		 */
		private NodeToolEntry(String title, String description,
				List elementTypes) {
			super(title, description, null, null);
			this.elementTypes = elementTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeCreationTool(elementTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}
}
