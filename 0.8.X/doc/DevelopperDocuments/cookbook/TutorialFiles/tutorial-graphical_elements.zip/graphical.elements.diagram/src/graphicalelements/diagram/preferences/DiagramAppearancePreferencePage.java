package graphicalelements.diagram.preferences;

import graphicalelements.diagram.part.GraphicalElementsDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	 * @generated
	 */
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(GraphicalElementsDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
