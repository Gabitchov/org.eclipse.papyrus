package graphicalelements.diagram.navigator;

import graphicalelements.Behavior;
import graphicalelements.Interaction;
import graphicalelements.Lifeline;
import graphicalelements.diagram.edit.parts.BehaviorEditPart;
import graphicalelements.diagram.edit.parts.InteractionEditPart;
import graphicalelements.diagram.edit.parts.LifelineEditPart;
import graphicalelements.diagram.edit.parts.RootEditPart;
import graphicalelements.diagram.part.GraphicalElementsDiagramEditorPlugin;
import graphicalelements.diagram.part.GraphicalElementsVisualIDRegistry;
import graphicalelements.diagram.providers.GraphicalElementsElementTypes;

import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class GraphicalElementsNavigatorLabelProvider extends LabelProvider
		implements ICommonLabelProvider, ITreePathLabelProvider {

	/**
	 * @generated
	 */
	static {
		GraphicalElementsDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put(
						"Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		GraphicalElementsDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put(
						"Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof GraphicalElementsNavigatorItem
				&& !isOwnView(((GraphicalElementsNavigatorItem) element)
						.getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	 * @generated
	 */
	public Image getImage(Object element) {
		if (element instanceof GraphicalElementsNavigatorGroup) {
			GraphicalElementsNavigatorGroup group = (GraphicalElementsNavigatorGroup) element;
			return GraphicalElementsDiagramEditorPlugin.getInstance()
					.getBundledImage(group.getIcon());
		}

		if (element instanceof GraphicalElementsNavigatorItem) {
			GraphicalElementsNavigatorItem navigatorItem = (GraphicalElementsNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		return super.getImage(element);
	}

	/**
	 * @generated
	 */
	public Image getImage(View view) {
		switch (GraphicalElementsVisualIDRegistry.getVisualID(view)) {
		case RootEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Diagram?http://graphicalelements/1.0?Root", GraphicalElementsElementTypes.Root_1000); //$NON-NLS-1$
		case InteractionEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://graphicalelements/1.0?Interaction", GraphicalElementsElementTypes.Interaction_2001); //$NON-NLS-1$
		case LifelineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://graphicalelements/1.0?Lifeline", GraphicalElementsElementTypes.Lifeline_3003); //$NON-NLS-1$
		case BehaviorEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://graphicalelements/1.0?Behavior", GraphicalElementsElementTypes.Behavior_3004); //$NON-NLS-1$
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = GraphicalElementsDiagramEditorPlugin
				.getInstance().getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null
				&& elementType != null
				&& GraphicalElementsElementTypes
						.isKnownElementType(elementType)) {
			image = GraphicalElementsElementTypes.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public String getText(Object element) {
		if (element instanceof GraphicalElementsNavigatorGroup) {
			GraphicalElementsNavigatorGroup group = (GraphicalElementsNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof GraphicalElementsNavigatorItem) {
			GraphicalElementsNavigatorItem navigatorItem = (GraphicalElementsNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		return super.getText(element);
	}

	/**
	 * @generated
	 */
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (GraphicalElementsVisualIDRegistry.getVisualID(view)) {
		case RootEditPart.VISUAL_ID:
			return getRoot_1000Text(view);
		case InteractionEditPart.VISUAL_ID:
			return getInteraction_2001Text(view);
		case LifelineEditPart.VISUAL_ID:
			return getLifeline_3003Text(view);
		case BehaviorEditPart.VISUAL_ID:
			return getBehavior_3004Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	 * @generated
	 */
	private String getRoot_1000Text(View view) {
		return ""; //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private String getInteraction_2001Text(View view) {
		Interaction domainModelElement = (Interaction) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			GraphicalElementsDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 2001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getLifeline_3003Text(View view) {
		Lifeline domainModelElement = (Lifeline) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			GraphicalElementsDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 3003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getBehavior_3004Text(View view) {
		Behavior domainModelElement = (Behavior) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			GraphicalElementsDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 3004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$ //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$ //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	 * @generated
	 */
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return RootEditPart.MODEL_ID.equals(GraphicalElementsVisualIDRegistry
				.getModelID(view));
	}

}
