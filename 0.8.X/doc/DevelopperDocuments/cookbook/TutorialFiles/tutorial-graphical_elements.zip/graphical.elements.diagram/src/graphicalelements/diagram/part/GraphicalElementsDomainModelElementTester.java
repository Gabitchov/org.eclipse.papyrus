package graphicalelements.diagram.part;

import graphicalelements.GraphicalelementsPackage;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

/**
 * @generated
 */
public class GraphicalElementsDomainModelElementTester extends PropertyTester {

	/**
	 * @generated
	 */
	public boolean test(Object receiver, String method, Object[] args,
			Object expectedValue) {
		if (false == receiver instanceof EObject) {
			return false;
		}
		EObject eObject = (EObject) receiver;
		EClass eClass = eObject.eClass();
		if (eClass == GraphicalelementsPackage.eINSTANCE.getRoot()) {
			return true;
		}
		if (eClass == GraphicalelementsPackage.eINSTANCE.getInteraction()) {
			return true;
		}
		if (eClass == GraphicalelementsPackage.eINSTANCE.getLifeline()) {
			return true;
		}
		if (eClass == GraphicalelementsPackage.eINSTANCE.getBehavior()) {
			return true;
		}
		if (eClass == GraphicalelementsPackage.eINSTANCE.getNamedElement()) {
			return true;
		}
		return false;
	}

}
