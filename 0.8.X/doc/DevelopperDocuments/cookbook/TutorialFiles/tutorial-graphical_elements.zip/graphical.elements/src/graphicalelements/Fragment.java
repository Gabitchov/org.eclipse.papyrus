/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package graphicalelements;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fragment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see graphicalelements.GraphicalelementsPackage#getFragment()
 * @model abstract="true"
 * @generated
 */
public interface Fragment extends NamedElement {
} // Fragment
