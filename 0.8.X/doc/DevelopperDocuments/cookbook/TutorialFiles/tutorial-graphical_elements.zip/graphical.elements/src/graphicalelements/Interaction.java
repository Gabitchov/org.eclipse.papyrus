/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package graphicalelements;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interaction</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link graphicalelements.Interaction#getFragments <em>Fragments</em>}</li>
 *   <li>{@link graphicalelements.Interaction#getLifelines <em>Lifelines</em>}</li>
 *   <li>{@link graphicalelements.Interaction#getBehaviors <em>Behaviors</em>}</li>
 * </ul>
 * </p>
 *
 * @see graphicalelements.GraphicalelementsPackage#getInteraction()
 * @model
 * @generated
 */
public interface Interaction extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Fragments</b></em>' containment reference list.
	 * The list contents are of type {@link graphicalelements.Fragment}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fragments</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fragments</em>' containment reference list.
	 * @see graphicalelements.GraphicalelementsPackage#getInteraction_Fragments()
	 * @model containment="true"
	 * @generated
	 */
	EList<Fragment> getFragments();

	/**
	 * Returns the value of the '<em><b>Lifelines</b></em>' containment reference list.
	 * The list contents are of type {@link graphicalelements.Lifeline}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lifelines</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lifelines</em>' containment reference list.
	 * @see graphicalelements.GraphicalelementsPackage#getInteraction_Lifelines()
	 * @model containment="true"
	 * @generated
	 */
	EList<Lifeline> getLifelines();

	/**
	 * Returns the value of the '<em><b>Behaviors</b></em>' containment reference list.
	 * The list contents are of type {@link graphicalelements.Behavior}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Behaviors</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Behaviors</em>' containment reference list.
	 * @see graphicalelements.GraphicalelementsPackage#getInteraction_Behaviors()
	 * @model containment="true"
	 * @generated
	 */
	EList<Behavior> getBehaviors();

} // Interaction
