/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package graphicalelements;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lifeline</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see graphicalelements.GraphicalelementsPackage#getLifeline()
 * @model
 * @generated
 */
public interface Lifeline extends Fragment, NamedElement {
} // Lifeline
