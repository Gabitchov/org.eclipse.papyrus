/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package graphicalelements.impl;

import graphicalelements.GraphicalelementsPackage;
import graphicalelements.Lifeline;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Lifeline</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class LifelineImpl extends FragmentImpl implements Lifeline {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LifelineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GraphicalelementsPackage.Literals.LIFELINE;
	}

} //LifelineImpl
