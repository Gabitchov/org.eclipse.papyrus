/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package graphicalelements;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link graphicalelements.Behavior#getBelongsTo <em>Belongs To</em>}</li>
 * </ul>
 * </p>
 *
 * @see graphicalelements.GraphicalelementsPackage#getBehavior()
 * @model
 * @generated
 */
public interface Behavior extends Fragment, NamedElement {
	/**
	 * Returns the value of the '<em><b>Belongs To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Belongs To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Belongs To</em>' reference.
	 * @see #setBelongsTo(Lifeline)
	 * @see graphicalelements.GraphicalelementsPackage#getBehavior_BelongsTo()
	 * @model
	 * @generated
	 */
	Lifeline getBelongsTo();

	/**
	 * Sets the value of the '{@link graphicalelements.Behavior#getBelongsTo <em>Belongs To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Belongs To</em>' reference.
	 * @see #getBelongsTo()
	 * @generated
	 */
	void setBelongsTo(Lifeline value);

} // Behavior
